Dies ist eine Vorlage, um wirklich coole Seiten auf NomadNet-Knoten zu erstellen. 
Es hat keine Anforderungen außerhalb der Standard-Python3-Module.
Die Daten werden in JSON-Dateien gespeichert. 
Obwohl es nicht das Beste für Knoten mit viel Verkehr ist, 
läuft es auf so ziemlich allem, was Python3 hat.

Diese Vorlage behandelt:
* Benutzerregistrierung und -anmeldung
* Zuordnen der Reticulum-Identität zum Benutzerkonto
* Benutzer können sich gegenseitig Nachrichten schicken (intern, nicht über LXMF)
* Administrative Verwaltung der Benutzer
* Beispielseite zur Erstellung eigener Seiten, die eine Authentifizierung erfordern.

# Standard Login
admin / admin

# Installation
Klonen Sie das Repository in den Ordner, in dem die Seiten auf dem Server liegen. 
Beispiel: /home/reticulum/.nomadnetwork/storage/pages

# Konfiguration
Öffnen Sie core.py und passen Sie sie nach Ihren Wünschen an. 
page_path und data_directory MÜSSEN gesetzt werden.

# Verwendung
Siehe example.mu für ein Beispiel einer Seite. 
Sie können die "Plugins" verwenden, indem Sie einen Link zu jedem einzelnen hinzufügen.